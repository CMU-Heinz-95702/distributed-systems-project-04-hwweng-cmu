

package ds.project4webservlet;

import static com.mongodb.client.model.Filters.eq;

import com.mongodb.client.*;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;


public class MongoDB {
    // Replace the placeholder with your MongoDB deployment's connection string
    static String uri = "mongodb+srv://hweng:Frank0802@cluster0.nxsho.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

    static MongoClient mongoClient = MongoClients.create(uri);


    // Method to log request data to MongoDB
    public static void logScoresRequestData(String phoneModel, String requestType, String requestDate, String userInputYear,
                                      String userInputTeam, int statusCode) {

        // database and collection code goes here
        MongoDatabase db = mongoClient.getDatabase("connectionLog");
        MongoCollection<Document> coll = db.getCollection("getScores");

        // insert code goes here
        Document doc1 = new Document("phoneModel", phoneModel).append("requestType", requestType).
                append("requestDate", requestDate).append("userInputYear", userInputYear).
                append("userInputTeam", userInputTeam).append("statusCode", statusCode);

        coll.insertOne(doc1);

    }

    // Method to log request data to MongoDB
    public static void logConferenceInfoRequestData(String phoneModel, String requestType, String requestDate,
                                                    String userInputConference, int statusCode) {

        // database and collection code goes here
        MongoDatabase db = mongoClient.getDatabase("connectionLog");
        MongoCollection<Document> coll = db.getCollection("getConferenceInfo");

        // insert code goes here
        Document doc1 = new Document("phoneModel", phoneModel).append("requestType", requestType).
                append("requestDate", requestDate).append("userInputConference", userInputConference).
                append("statusCode", statusCode);

        coll.insertOne(doc1);
    }

    public static List<Document> lastFiveConferenceRequest(){
        // Access the database
        MongoDatabase database = mongoClient.getDatabase("connectionLog"); // Replace with your database name

        // Access the collection
        MongoCollection<Document> collection = database.getCollection("getConferenceInfo"); // Replace with your collection name

        // Query to fetch the last five requests
        MongoCursor<Document> cursor = collection
                .find()
                .sort(new Document("requestDate", -1)) // Sort by requestDate descending
                .limit(5)
                .iterator();


        // Convert MongoCursor results to a List
        List<Document> lastFiveRequests = new ArrayList<>();
        while (cursor.hasNext()) {
            lastFiveRequests.add(cursor.next());
            System.out.println(lastFiveRequests);
        }




        return lastFiveRequests;



    }

    public static List<Document> lastFiveScoresRequest(){
        // Access the database
        MongoDatabase database = mongoClient.getDatabase("connectionLog"); // Replace with your database name

        // Access the collection
        MongoCollection<Document> collection = database.getCollection("getScores"); // Replace with your collection name

        // Query to fetch the last five requests
        MongoCursor<Document> cursor = collection
                .find()
                .sort(new Document("requestDate", -1)) // Sort by requestDate descending
                .limit(5)
                .iterator();


        // Convert MongoCursor results to a List
        List<Document> lastFiveRequests = new ArrayList<>();
        while (cursor.hasNext()) {
            lastFiveRequests.add(cursor.next());
            System.out.println(lastFiveRequests);
        }




        return lastFiveRequests;



    }
}
