package ds.project4webservlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;


@WebServlet("/collegeFootballData")
public class CollegeFootballServlet extends HttpServlet {

    private static final String CFBD_API_URL = "https://api.collegefootballdata.com";
    private static final String API_KEY = "1gViricKRSebxrhqPlG/z1pIC729JqxThAFmohjvS7LNnFzCzT4jHaJ/c5gC9k0e"; // Replace with your CFBD API key

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String type = request.getParameter("type");

        if (type == null || type.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"Request type is required\"}");
            return;

        }

        String phoneModel;
        String requestType;
        String requestDate;
        String userInputYear;
        String userInputTeam;
        String userInputConference;
        int statusCode;

        switch (type) {
            case "getScores":
                handleGetScores(request, response);
                // log data
                phoneModel = request.getHeader("User-Agent");
                requestType = "getScores";
                requestDate = LocalDateTime.now().toString();
                userInputYear = request.getParameter("year");
                userInputTeam = request.getParameter("team");
                statusCode = HttpServletResponse.SC_OK;
                // send to mongo
                MongoDB.logScoresRequestData(phoneModel,requestType,requestDate,userInputYear,userInputTeam,statusCode);
                break;
            case "getConferenceInfo":
                handleGetConferenceInfo(request, response);
//                // log data
                phoneModel = request.getHeader("User-Agent");
                requestType = "getConferenceInfo";
                requestDate = LocalDateTime.now().toString();
                userInputConference = request.getParameter("conference");
                statusCode = HttpServletResponse.SC_OK;
//                // send to mongo
                MongoDB.logConferenceInfoRequestData(phoneModel,requestType,requestDate,userInputConference,statusCode);
                break;
            default:
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"error\": \"Invalid request type\"}");
                break;
        }
    }

    private void handleGetScores(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String year = request.getParameter("year");
        String team = request.getParameter("team");

        // Validate the input parameters
        if (year == null || year.isEmpty() || team == null || team.isEmpty()) {

            sendErrorResponse(response, HttpServletResponse.SC_BAD_REQUEST, "Year and team parameters are required.");
            return;
        }

        // Replace spaces in team name with '+'
        team = team.replace(" ", "+");

        // Construct the CFBD API URL for fetching scores
        String apiUrl = CFBD_API_URL + "/records?year=" + year + "&team=" + team;

        HttpURLConnection connection = null;

        try {
            // Set up the API connection
            URL url = new URL(apiUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Authorization", "Bearer " + API_KEY);
            connection.setRequestProperty("Content-Type", "application/json");

            int statusCode = connection.getResponseCode();

            if (statusCode == HttpURLConnection.HTTP_OK) {
                // Read the API response
                Scanner scanner = new Scanner(connection.getInputStream());
                StringBuilder result = new StringBuilder();
                while (scanner.hasNextLine()) {
                    result.append(scanner.nextLine());
                }
                scanner.close();

                // Parse the API response
                JSONArray scoresArray = new JSONArray(result.toString());
                JSONArray formattedScoresArray = new JSONArray();

                for (int i = 0; i < scoresArray.length(); i++) {
                    JSONObject game = scoresArray.getJSONObject(i);

                    // Extract and format relevant fields
                    JSONObject formattedGame = new JSONObject();
                    formattedGame.put("year", game.optInt("year", 0));
                    formattedGame.put("team", game.optString("team", "N/A"));
                    formattedGame.put("conference", game.optString("conference", "N/A"));
                    formattedGame.put("division", game.optString("division", "N/A"));
                    formattedGame.put("expectedWins", game.optDouble("expectedWins", 0));

                    // Total stats
                    JSONObject totalStats = game.optJSONObject("total");
                    if (totalStats != null) {
                        formattedGame.put("totalGames", totalStats.optInt("games", 0));
                        formattedGame.put("totalWins", totalStats.optInt("wins", 0));
                        formattedGame.put("totalLosses", totalStats.optInt("losses", 0));
                        formattedGame.put("totalTies", totalStats.optInt("ties", 0));
                    }

                    // Conference games stats
                    JSONObject conferenceStats = game.optJSONObject("conferenceGames");
                    if (conferenceStats != null) {
                        formattedGame.put("conferenceGames", conferenceStats.optInt("games", 0));
                        formattedGame.put("conferenceWins", conferenceStats.optInt("wins", 0));
                        formattedGame.put("conferenceLosses", conferenceStats.optInt("losses", 0));
                        formattedGame.put("conferenceTies", conferenceStats.optInt("ties", 0));
                    }

                    // Home games stats
                    JSONObject homeStats = game.optJSONObject("homeGames");
                    if (homeStats != null) {
                        formattedGame.put("homeGames", homeStats.optInt("games", 0));
                        formattedGame.put("homeWins", homeStats.optInt("wins", 0));
                        formattedGame.put("homeLosses", homeStats.optInt("losses", 0));
                        formattedGame.put("homeTies", homeStats.optInt("ties", 0));
                    }

                    // Away games stats
                    JSONObject awayStats = game.optJSONObject("awayGames");
                    if (awayStats != null) {
                        formattedGame.put("awayGames", awayStats.optInt("games", 0));
                        formattedGame.put("awayWins", awayStats.optInt("wins", 0));
                        formattedGame.put("awayLosses", awayStats.optInt("losses", 0));
                        formattedGame.put("awayTies", awayStats.optInt("ties", 0));
                    }

                    // Add the formatted game object to the array
                    formattedScoresArray.put(formattedGame);
                }

                // Send the formatted response to the client
                sendJsonResponse(response, formattedScoresArray.toString());
            } else {
                // Handle non-OK response codes
                sendErrorResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to fetch data from CFBD API.");
            }
        } catch (Exception e) {
            // Handle exceptions
            sendErrorResponse(response, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error: " + e.getMessage());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private void handleGetConferenceInfo(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String conference = request.getParameter("conference");

        if (conference == null || conference.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"Conference parameter is required\"}");
            return;
        }

        HttpURLConnection connection = null;
        try {
            // Construct the API URL
            String apiUrl = CFBD_API_URL + "/teams?conference=" + conference;

            // Send request to the CFBD API
            URL url = new URL(apiUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Authorization", "Bearer " + API_KEY);
            connection.setRequestProperty("Content-Type", "application/json");

            int status = connection.getResponseCode();
            if (status == HttpURLConnection.HTTP_OK) {
                // Read the CFBD API response
                Scanner scanner = new Scanner(connection.getInputStream());
                StringBuilder result = new StringBuilder();
                while (scanner.hasNextLine()) {
                    result.append(scanner.nextLine());
                }
                scanner.close();

                // Parse and restructure the JSON response
                JSONArray teamsArray = new JSONArray(result.toString());
                JSONArray formattedTeamsArray = new JSONArray();

                for (int i = 0; i < teamsArray.length(); i++) {
                    JSONObject team = teamsArray.getJSONObject(i);

                    // Create a simplified JSON object for each team
                    JSONObject formattedTeam = new JSONObject();
                    formattedTeam.put("school", team.optString("school", "N/A"));
                    formattedTeam.put("mascot", team.optString("mascot", "N/A"));
                    formattedTeam.put("city", team.optJSONObject("location").optString("city", "N/A"));
                    formattedTeam.put("state", team.optJSONObject("location").optString("state", "N/A"));

                    // Add the formatted team object to the array
                    formattedTeamsArray.put(formattedTeam);
                }

                // Send the formatted JSON array to the mobile app
                response.setContentType("application/json");
                PrintWriter out = response.getWriter();
                out.print(formattedTeamsArray.toString());
                out.flush();

                //LOG
                System.out.println("Request Type: " + request.getParameter("type"));
                System.out.println("Conference: " + request.getParameter("conference"));
                System.out.println("Generated Response: " + formattedTeamsArray.toString());

            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"error\": \"Failed to fetch data from CFBD API\"}");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"" + e.getMessage() + "\"}");
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private void sendJsonResponse(HttpServletResponse response, String jsonResponse) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        PrintWriter out = response.getWriter();
        out.print(jsonResponse);
        out.flush();
    }
    private void sendErrorResponse(HttpServletResponse response, int statusCode, String message) throws IOException {
        response.setStatus(statusCode);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        JSONObject errorJson = new JSONObject();
        errorJson.put("error", message);

        PrintWriter out = response.getWriter();
        out.print(errorJson.toString());
        out.flush();
    }





}
