package ds.project4webservlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Map;
import java.util.List;

@WebServlet("/dashboard") // URL mapping for the servlet
public class DashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Example: Add attributes to the request for use in the JSP

        // Pass data to the JSP
        System.out.println(MongoDB.getTopPhoneModel());
        request.setAttribute("lastFiveScoresRequests", MongoDB.lastFiveScoresRequest());
        request.setAttribute("lastFiveConferenceRequests", MongoDB.lastFiveConferenceRequest());
        request.setAttribute("numberOfTotalRequest", MongoDB.numberOfTotalRequest());
        request.setAttribute("numberOfConferenceRequest", MongoDB.numberOfConferenceRequest());
        request.setAttribute("numberOfScoresRequest", MongoDB.numberOfScoresRequest());

        request.setAttribute("TopPhoneModel", MongoDB.getTopPhoneModel());
        // Forward to the JSP
        request.getRequestDispatcher("/Dashboard.jsp").forward(request, response);

    }
}
